Source:
https://www.kaggle.com/clmentbisaillon/fake-and-real-news-dataset